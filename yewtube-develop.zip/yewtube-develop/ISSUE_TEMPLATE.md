<!--- Provide a general summary of the issue in the Title above -->

## Issue / Suggestion
<!--- If you're describing a bug, tell us what error you are experiencing -->
<!--- If you're suggesting a change/improvement, tell us how it should work -->

## Your Environment
<!--- Include as many relevant details about the environment you experienced the bug in -->
<!--- Run "mpsyt --version" and post your version information here --->
<!-- What version of the OS are you running, any other  -->
<!-- What music player are you using with mps-youtube, version? -->
