mps_youtube.commands.album_search module
========================================

.. automodule:: mps_youtube.commands.album_search
    :members:
    :undoc-members:
    :show-inheritance:
