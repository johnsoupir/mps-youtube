mps_youtube.commands.play module
================================

.. automodule:: mps_youtube.commands.play
    :members:
    :undoc-members:
    :show-inheritance:
