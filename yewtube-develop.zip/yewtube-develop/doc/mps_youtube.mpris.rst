mps_youtube.mpris module
========================

.. automodule:: mps_youtube.mpris
    :members:
    :undoc-members:
    :show-inheritance:
