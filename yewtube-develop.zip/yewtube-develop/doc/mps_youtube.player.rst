mps_youtube.player module
=========================

.. automodule:: mps_youtube.player
    :members:
    :undoc-members:
    :show-inheritance:
