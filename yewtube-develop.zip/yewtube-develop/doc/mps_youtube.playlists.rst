mps_youtube.playlists module
============================

.. automodule:: mps_youtube.playlists
    :members:
    :undoc-members:
    :show-inheritance:
