mps_youtube.terminalsize module
===============================

.. automodule:: mps_youtube.terminalsize
    :members:
    :undoc-members:
    :show-inheritance:
