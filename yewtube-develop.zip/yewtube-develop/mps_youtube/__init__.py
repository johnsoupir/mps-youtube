__version__ = "1.0.0"
__notes__ = "released 14 October 2021"
__author__ = "iamtalhaasghar"
__license__ = "GPLv3"
__url__ = "https://github.com/iamtalhaasghar/yewtube"

from . import init
init.init()
from . import main
